package com.example.lupa.filosoficopy;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class Halamanutama extends AppCompatActivity {

    ImageView pesanan,filosofi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_halamanutama);

        pesanan = (ImageView)findViewById(R.id.img_pesan);
        filosofi = (ImageView)findViewById(R.id.img_filosofi);

        pesanan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mintent = new Intent(getApplicationContext(), Pesanan.class);
                startActivity(mintent);
            }
        });

        filosofi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mintent = new Intent(getApplicationContext(), Edukasi.class);
                startActivity(mintent);
            }
        });
    }
}
